/*
TinyScreen.cpp - Last modified 11 February 2016

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Written by Ben Rose for TinyCircuits.

The latest version of this library can be found at https://tiny-circuits.com/
*/

#include "TinyScreen.h"
#include <avr/pgmspace.h>
#include "pins_arduino.h"
#include "wiring_private.h"
#include <SPI.h>
#include <Wire.h>

//These delays are used to allow hardware drawing commands on the SSD1331 to execute
#ifndef TS_USE_DELAY
#define TS_USE_DELAY true
#endif

/*
SPI optimization defines for known architectures
*/

static int xOff, yOff;

#if defined(ARDUINO_ARCH_AVR)
  #define TS_SPI_SET_DATA_REG(x) SPDR=(x)
#elif defined(ARDUINO_ARCH_SAMD)
  #define TS_SPI_SET_DATA_REG(x) if(_externalIO){SERCOM1->SPI.DATA.bit.DATA=(x);}else{SERCOM4->SPI.DATA.bit.DATA=(x);}
#elif defined(ARDUINO_ARCH_ESP8266)
  #define TS_SPI_SET_DATA_REG(x) SPI1W0 = (x); SPI1CMD |= SPIBUSY
#elif defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)

#include "hardware/dma.h"
static uint32_t pull_stall_mask;
static int8_t pio_sm;
static int32_t dma_tx_channel;
static dma_channel_config dma_tx_config;
static PIO tft_pio;
static uint32_t program_offset;
static uint32_t pio_instr_jmp8;
static uint32_t pio_instr_fill;
static uint32_t pio_instr_addr;
static uint32_t pio_instr_set_dc;
static uint32_t pio_instr_clr_dc;

#define TFT_CASET   0x15 // SETCOLUMN
#define TFT_PASET   0x75 // SETROW
#define TFT_RAMWR   0x5C // WRITERAM
#define TFT_INVOFF  0xA6 // NORMALDISPLAY
#define TFT_INVON   0xA7 // INVERTDISPLAY

static int colSetCommand;
static int rowSetCommand;
static int writeRamCommand;
static int cgramOff;

// ST7789 specific commands used in init
#define ST7789_NOP			0x00
#define ST7789_SWRESET		0x01
#define ST7789_RDDID		0x04
#define ST7789_RDDST		0x09

#define ST7789_RDDPM		0x0A      // Read display power mode
#define ST7789_RDD_MADCTL	0x0B      // Read display MADCTL
#define ST7789_RDD_COLMOD	0x0C      // Read display pixel format
#define ST7789_RDDIM		0x0D      // Read display image mode
#define ST7789_RDDSM		0x0E      // Read display signal mode
#define ST7789_RDDSR		0x0F      // Read display self-diagnostic result (ST7789V)

#define ST7789_SLPIN		0x10
#define ST7789_SLPOUT		0x11
#define ST7789_PTLON		0x12
#define ST7789_NORON		0x13

#define ST7789_INVOFF		0x20
#define ST7789_INVON		0x21
#define ST7789_GAMSET		0x26      // Gamma set
#define ST7789_DISPOFF		0x28
#define ST7789_DISPON		0x29
#define ST7789_CASET		0x2A
#define ST7789_RASET		0x2B
#define ST7789_RAMWR		0x2C
#define ST7789_RGBSET		0x2D      // Color setting for 4096, 64K and 262K colors
#define ST7789_RAMRD		0x2E

#define ST7789_PTLAR		0x30
#define ST7789_VSCRDEF		0x33      // Vertical scrolling definition (ST7789V)
#define ST7789_TEOFF		0x34      // Tearing effect line off
#define ST7789_TEON			0x35      // Tearing effect line on
#define ST7789_MADCTL		0x36      // Memory data access control
#define ST7789_VSCRSADD		0x37      // Vertical screoll address
#define ST7789_IDMOFF		0x38      // Idle mode off
#define ST7789_IDMON		0x39      // Idle mode on
#define ST7789_RAMWRC		0x3C      // Memory write continue (ST7789V)
#define ST7789_RAMRDC		0x3E      // Memory read continue (ST7789V)
#define ST7789_COLMOD		0x3A

#define ST7789_RAMCTRL		0xB0      // RAM control
#define ST7789_RGBCTRL		0xB1      // RGB control
#define ST7789_PORCTRL		0xB2      // Porch control
#define ST7789_FRCTRL1		0xB3      // Frame rate control
#define ST7789_PARCTRL		0xB5      // Partial mode control
#define ST7789_GCTRL		0xB7      // Gate control
#define ST7789_GTADJ		0xB8      // Gate on timing adjustment
#define ST7789_DGMEN		0xBA      // Digital gamma enable
#define ST7789_VCOMS		0xBB      // VCOMS setting
#define ST7789_LCMCTRL		0xC0      // LCM control
#define ST7789_IDSET		0xC1      // ID setting
#define ST7789_VDVVRHEN		0xC2      // VDV and VRH command enable
#define ST7789_VRHS			0xC3      // VRH set
#define ST7789_VDVSET		0xC4      // VDV setting
#define ST7789_VCMOFSET		0xC5      // VCOMS offset set
#define ST7789_FRCTR2		0xC6      // FR Control 2
#define ST7789_CABCCTRL		0xC7      // CABC control
#define ST7789_REGSEL1		0xC8      // Register value section 1
#define ST7789_REGSEL2		0xCA      // Register value section 2
#define ST7789_PWMFRSEL		0xCC      // PWM frequency selection
#define ST7789_PWCTRL1		0xD0      // Power control 1
#define ST7789_VAPVANEN		0xD2      // Enable VAP/VAN signal output
#define ST7789_CMD2EN		0xDF      // Command 2 enable
#define ST7789_PVGAMCTRL	0xE0      // Positive voltage gamma control
#define ST7789_NVGAMCTRL	0xE1      // Negative voltage gamma control
#define ST7789_DGMLUTR		0xE2      // Digital gamma look-up table for red
#define ST7789_DGMLUTB		0xE3      // Digital gamma look-up table for blue
#define ST7789_GATECTRL		0xE4      // Gate control
#define ST7789_SPI2EN		0xE7      // SPI2 enable
#define ST7789_PWCTRL2		0xE8      // Power control 2
#define ST7789_EQCTRL		0xE9      // Equalize time control
#define ST7789_PROMCTRL		0xEC      // Program control
#define ST7789_PROMEN		0xFA      // Program mode enable
#define ST7789_NVMSET		0xFC      // NVM setting
#define ST7789_PROMACT		0xFE      // Program action

#define TFT_MAD_MY  0x80
#define TFT_MAD_MX  0x40
#define TFT_MAD_MV  0x20
#define TFT_MAD_ML  0x10
#define TFT_MAD_RGB 0x00
#define TFT_MAD_BGR 0x08

#define tft_io_wrap_target 27
#define tft_io_wrap 31

#define tft_io_offset_start_8 0u
#define tft_io_offset_set_addr_window 3u
#define tft_io_offset_block_fill 17u
#define tft_io_offset_start_tx 27u

#define TX_FIFO  tft_pio->txf[pio_sm]

#define write8(C) tft_pio->sm[pio_sm].instr = pio_instr_jmp8; TX_FIFO = (C); stallWait()
#define write16(C) fifoWait(1); TX_FIFO = (C)

static inline void stallWait()
{
  tft_pio->fdebug = pull_stall_mask; while (!(tft_pio->fdebug & pull_stall_mask));
}

static inline void clearDC()
{
  stallWait(); tft_pio->sm[pio_sm].instr = pio_instr_clr_dc;
}

static inline void setDC()
{
  tft_pio->sm[pio_sm].instr = pio_instr_set_dc;
}

#define swap(x,y) x ^= y; y ^= x; x ^= y
#define CS_L sio_hw->gpio_clr = (1ul << RPTVM_PIN_CS)
#define CS_H stallWait(); sio_hw->gpio_set = (1ul << RPTVM_PIN_CS)

static inline void fifoWait(const int level)
{
  while (((tft_pio->flevel >> (pio_sm * 8)) & 0x000F) > (8-level)){}
}

static inline void writeCommand(const uint8_t c)
{
  CS_L; clearDC();
  write8(c);
  setDC(); CS_H;
}

static inline void writeData(const uint8_t d)
{
  CS_L; setDC();
  write8(d);
  CS_L; CS_H;
}

void setWindowSSD1357(const int32_t y0, const int32_t x0, const int32_t y1, const int32_t x1)
{
  stallWait();
  tft_pio->sm[pio_sm].instr = pio_instr_addr;
  clearDC(); write8(colSetCommand); // DC clear
  setDC(); write16((x1+yOff) | ((x0+yOff) << 8)); // DC drive
  clearDC(); write8(rowSetCommand);
  setDC(); write16(y1 | (y0 << 8));
  clearDC(); write8(writeRamCommand);
  setDC();
}

void setWindowST7789(const int32_t x0, const int32_t y0, const int32_t x1, const int32_t y1)
{
  stallWait();
  tft_pio->sm[pio_sm].instr = pio_instr_addr;
  TX_FIFO = ST7789_CASET;
  TX_FIFO = ((x0+xOff)<<16) | (x1+xOff);
  TX_FIFO = ST7789_RASET;
  TX_FIFO = ((y0+yOff)<<16) | (y1+yOff);
  TX_FIFO = ST7789_RAMWR;
}

void setXST7789(const int32_t x0, const int32_t x1)
{
  stallWait();
  tft_pio->sm[pio_sm].instr = pio_instr_addr;
  TX_FIFO = ST7789_CASET;
  TX_FIFO = ((x0+xOff)<<16) | (x1+xOff);
  TX_FIFO = ST7789_RAMWR;
}

void setYST7789(const int32_t y0, const int32_t y1)
{
  stallWait();
  tft_pio->sm[pio_sm].instr = pio_instr_addr;
  TX_FIFO = ST7789_RASET;
  TX_FIFO = ((y0+yOff)<<16) | (y1+yOff);
  TX_FIFO = ST7789_RAMWR;
}

void setXSSD1357(const int32_t x0, const int32_t x1)
{
  stallWait();
  tft_pio->sm[pio_sm].instr = pio_instr_addr;
  clearDC(); write8(TFT_PASET);
  setDC(); write16((x1+xOff) | ((x0+xOff) << 8));
  clearDC(); write8(TFT_RAMWR);
  setDC();
}

void setYSSD1357(const int32_t y0, const int32_t y1)
{
  stallWait();
  tft_pio->sm[pio_sm].instr = pio_instr_addr;
  clearDC(); write8(TFT_CASET);
  setDC(); write16((y1+yOff) | ((y0+yOff) << 8));
  clearDC(); write8(TFT_RAMWR);
  setDC();
}

static void (*setWindow)(const int32_t, const int32_t, const int32_t, const int32_t);
static void (*setXFunc)(const int32_t, const int32_t);
static void (*setYFunc)(const int32_t, const int32_t);

static inline void pushBlock16(const uint16_t color, const uint32_t len)
{
  if (len > 0) {
    stallWait();
    tft_pio->sm[pio_sm].instr = pio_instr_fill;
    TX_FIFO = color;
    TX_FIFO = len-1; // Decrement first as PIO sends n+1
  }
}

static inline void pushBlock8(const uint8_t color, const uint32_t len)
{
  /*
  if(len & 1)
  {
    stallWait();
    TX_FIFO = (color); // This one-byte push has to happen before the following call or we lose the top-left corner.
  }
  pushBlock16(color | (uint16_t(color) << 8), (len) >> 1);
  */
  if(len & 1)
  {
    stallWait();
    write8(color);
  }
  stallWait();
  pushBlock16(color | (color << 8), len >> 1);
}

static const uint16_t tft_io_program_instructions[] = {
    0x90a0, //  0: pull   block           side 0
    0x6019, //  1: out    pins, 25
    0x181e, //  2: jmp    30              side 1
    0xf022, //  3: set    x, 2            side 0
    0xe000, //  4: set    pins, 0
    0x90a0, //  5: pull   block           side 0
    0x6019, //  6: out    pins, 25
    0xb842, //  7: nop                    side 1
    0x7001, //  8: out    pins, 1         side 0
    0x18e8, //  9: jmp    !osre, 8        side 1
    0xf001, // 10: set    pins, 1         side 0
    0x003b, // 11: jmp    !x, 27
    0x80a0, // 12: pull   block
    0x7001, // 13: out    pins, 1         side 0
    0x18ed, // 14: jmp    !osre, 13       side 1
    0x1044, // 15: jmp    x--, 4          side 0
    0x001b, // 16: jmp    27
    0x90a0, // 17: pull   block           side 0
    0xa027, // 18: mov    x, osr
    0x80a0, // 19: pull   block
    0xa047, // 20: mov    y, osr
    0xb0e1, // 21: mov    osr, x          side 0
    0x7011, // 22: out    pins, 17        side 0
    0xb842, // 23: nop                    side 1
    0x7001, // 24: out    pins, 1         side 0
    0x18f8, // 25: jmp    !osre, 24       side 1
    0x1095, // 26: jmp    y--, 21         side 0
            //     .wrap_target
    0x90a0, // 27: pull   block           side 0
    0x7011, // 28: out    pins, 17        side 0
    0xb842, // 29: nop                    side 1
    0x7001, // 30: out    pins, 1         side 0
    0x18fe, // 31: jmp    !osre, 30       side 1
            //     .wrap
};

static const struct pio_program tft_io_program = {
    .instructions = tft_io_program_instructions,
    .length = 32,
    .origin = -1,
};

static inline pio_sm_config tft_io_program_get_default_config(uint offset) {
    pio_sm_config c = pio_get_default_sm_config();
    sm_config_set_wrap(&c, offset + 27, offset + 31);
    sm_config_set_sideset(&c, 2, true, false);
    return c;
}

static void pioinit(uint32_t clock_freq) {

  // Find a free SM on one of the PIO's
  tft_pio = pio0;

  /*
  pio_sm = pio_claim_unused_sm(tft_pio, false); // false means don't panic
  // Try pio1 if SM not found
  if (pio_sm < 0) {
    tft_pio = pio1;
    pio_sm = pio_claim_unused_sm(tft_pio, true); // panic this time if no SM is free
  }
  */

  // Find enough free space on one of the PIO's
  tft_pio = pio0;
  if (!pio_can_add_program(tft_pio, &tft_io_program)) {
    tft_pio = pio1;
    if (!pio_can_add_program(tft_pio, &tft_io_program)) {
      //Serial.println("No room for PIO program!");
      return;
    }
  }

  pio_sm = pio_claim_unused_sm(tft_pio, false);

  // Load the PIO program
  program_offset = pio_add_program(tft_pio, &tft_io_program);

  // Associate pins with the PIO
  pio_gpio_init(tft_pio, RPTVM_PIN_DC);
  pio_gpio_init(tft_pio, RPTVM_PIN_SCLK);
  pio_gpio_init(tft_pio, RPTVM_PIN_MOSI);

  // Configure the pins to be outputs
  pio_sm_set_consecutive_pindirs(tft_pio, pio_sm, RPTVM_PIN_DC, 1, true);
  pio_sm_set_consecutive_pindirs(tft_pio, pio_sm, RPTVM_PIN_SCLK, 1, true);
  pio_sm_set_consecutive_pindirs(tft_pio, pio_sm, RPTVM_PIN_MOSI, 1, true);

  // Configure the state machine
  pio_sm_config c = tft_io_program_get_default_config(program_offset);

  sm_config_set_set_pins(&c, RPTVM_PIN_DC, 1);
  // Define the single side-set pin
  sm_config_set_sideset_pins(&c, RPTVM_PIN_SCLK);
  // Define the pin used for data output
  sm_config_set_out_pins(&c, RPTVM_PIN_MOSI, 1);
  // Set clock divider, frequency is set up to 2% faster than specified, or next division down
  uint16_t clock_div = 0.98 + clock_get_hz(clk_sys) / (clock_freq * 2.0); // 2 cycles per bit
  sm_config_set_clkdiv(&c, clock_div);
  // Make a single 8 words FIFO from the 4 words TX and RX FIFOs
  sm_config_set_fifo_join(&c, PIO_FIFO_JOIN_TX);
  // The OSR register shifts to the left, sm designed to send MS byte of a colour first, autopull off
  sm_config_set_out_shift(&c, false, false, 0);
  // Now load the configuration
  pio_sm_init(tft_pio, pio_sm, program_offset + 27, &c);

  // Start the state machine.
  pio_sm_set_enabled(tft_pio, pio_sm, true);

  // Create the pull stall bit mask
  pull_stall_mask = 1u << (PIO_FDEBUG_TXSTALL_LSB + pio_sm);

  // Create the assembler instruction for the jump to byte send routine
  pio_instr_jmp8  = pio_encode_jmp(program_offset + tft_io_offset_start_8);
  pio_instr_fill  = pio_encode_jmp(program_offset + tft_io_offset_block_fill);
  pio_instr_addr  = pio_encode_jmp(program_offset + tft_io_offset_set_addr_window);
  pio_instr_set_dc = pio_encode_set((pio_src_dest)0, 1);
  pio_instr_clr_dc = pio_encode_set((pio_src_dest)0, 0);
}

#else
  #define TS_SPI_SET_DATA_REG(x) TSSPI->transfer(x)
#endif

#if defined(ARDUINO_ARCH_AVR)
  #define TS_SPI_SEND_WAIT() while(!(SPSR & _BV(SPIF)))
#elif defined(ARDUINO_ARCH_SAMD)
  #define TS_SPI_SEND_WAIT() if(_externalIO){while(SERCOM1->SPI.INTFLAG.bit.DRE == 0);}else{while(SERCOM4->SPI.INTFLAG.bit.DRE == 0);}
#elif defined(ARDUINO_ARCH_ESP8266)
  #define TS_SPI_SEND_WAIT() while(SPI1CMD & SPIBUSY)
#else
  #define TS_SPI_SEND_WAIT() if(0)
#endif

/*
TinyScreen uses an I2C GPIO chip to interface with the OLED control lines and buttons
TinyScreen+ has direct IO and uses the Arduino digital IO interface
writeGPIO(address, data);//write to SX1505
startCommand();//write SSD1331 chip select active with data/command signalling a command
startData();//write SSD1331 chip select active with data/command signalling data
endTransfer();//write SSD1331 chip select inactive
getButtons();//read button states, return as four LSBs in a byte- optional button mask
*/

void TinyScreen::writeGPIO(uint8_t regAddr, uint8_t regData)
{
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)

#elif defined(ARDUINO_ARCH_AVR)
  uint8_t oldTWBR=TWBR;
  TWBR=0;
#endif
  Wire.beginTransmission(GPIO_ADDR+_addr);
  Wire.write(regAddr);
  Wire.write(regData);
  Wire.endTransmission();
#if defined(ARDUINO_ARCH_AVR)
  TWBR=oldTWBR;
#endif
}

void TinyScreen::startCommand(void) {
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  tft_pio->fdebug = pull_stall_mask; while (!(tft_pio->fdebug & pull_stall_mask));
  tft_pio->sm[pio_sm].instr = pio_instr_clr_dc;
  sio_hw->gpio_clr = (1ul << RPTVM_PIN_CS);
#else
  if(_externalIO){
    writeGPIO(GPIO_RegData,GPIO_CMD_START);
  }else{
    digitalWrite(TSP_PIN_DC,LOW);
    digitalWrite(TSP_PIN_CS,LOW);
  }
#endif
}

void TinyScreen::startData(void) {
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  tft_pio->sm[pio_sm].instr = pio_instr_set_dc;
  sio_hw->gpio_clr = (1ul << RPTVM_PIN_CS);
#else
  if(_externalIO){
    writeGPIO(GPIO_RegData,GPIO_DATA_START);
  }else{
    digitalWrite(TSP_PIN_DC,HIGH);
    digitalWrite(TSP_PIN_CS,LOW);
  }
#endif
}

void TinyScreen::endTransfer(void) {
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  tft_pio->fdebug = pull_stall_mask; while (!(tft_pio->fdebug & pull_stall_mask));
  sio_hw->gpio_set = (1ul << RPTVM_PIN_CS);
#else
  if(_externalIO){
    writeGPIO(GPIO_RegData,GPIO_TRANSFER_END);
  }else{
    digitalWrite(TSP_PIN_CS,HIGH);
  }
#endif
}

uint8_t TinyScreen::getButtons(uint8_t buttonMask) {
  uint8_t buttons=0;
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)

#else
  if(_externalIO){
    Wire.beginTransmission(GPIO_ADDR+_addr);
    Wire.write(GPIO_RegData);
    Wire.endTransmission();
    Wire.requestFrom(GPIO_ADDR+_addr,1);
    buttons=Wire.read();
    //buttons are active low and MSBs, so flip and shift
    buttons=((~buttons)>>4)&0x0F;
  }else{
    if(!digitalRead(TSP_PIN_BT1))buttons|=0x01;
    if(!digitalRead(TSP_PIN_BT2))buttons|=0x02;
    if(!digitalRead(TSP_PIN_BT3))buttons|=0x04;
    if(!digitalRead(TSP_PIN_BT4))buttons|=0x08;
  }
  if(_flipDisplay){
    uint8_t flipped=0;
    flipped|=((buttons&TSButtonUpperLeft)<<2);
    flipped|=((buttons&TSButtonUpperRight)>>2);
    flipped|=((buttons&TSButtonLowerLeft)<<2);
    flipped|=((buttons&TSButtonLowerRight)>>2);
    buttons=flipped;
  }
#endif // defined
  return buttons&buttonMask;
}

uint8_t TinyScreen::getButtons(void) {
  return getButtons(TSButtonUpperLeft|TSButtonUpperRight|TSButtonLowerLeft|TSButtonLowerRight);
}

/*
SSD1331 Basics
goTo(x,y);//set OLED RAM to pixel address (x,y) with wrap around at x and y max
setX(x start, x end);//set OLED RAM to x start, wrap around at x end
setY(y start, y end);//set OLED RAM to y start, wrap around at y end
*/

void TinyScreen::goTo(uint8_t x, uint8_t y) {
  if(x>xMax||y>yMax)return;
  setX(x,xMax);
  setY(y,yMax);
}

void TinyScreen::setX(uint8_t x, uint8_t end) {
  startCommand();
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  setXFunc(x, end);
#else
  if(x>xMax)x=xMax;
  if(end>xMax)end=xMax;
  TSSPI->transfer(0x15);//set column
  TSSPI->transfer(x);
  TSSPI->transfer(end);
#endif
  endTransfer();
}

void TinyScreen::setY(uint8_t y, uint8_t end) {
  startCommand();
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  setYFunc(y, end);
#else
  if(y>yMax)y=yMax;
  if(end>yMax)end=yMax;
  TSSPI->transfer(0x75);//set row
  TSSPI->transfer(y);
  TSSPI->transfer(end);
#endif
  endTransfer();
}

/*
Hardware accelerated drawing functions:
clearWindow(x start, y start, width, height);//clears specified OLED controller memory
clearScreen();//clears entire screen
drawRect(x stary, y start, width, height, fill, 8bitcolor);//sets specified OLED controller memory to an 8 bit color, fill is a boolean
drawRect(x stary, y start, width, height, fill, 16bitcolor);//sets specified OLED controller memory to an 8 bit color, fill is a boolean
drawRect(x stary, y start, width, height, fill, red, green, blue);//like above, but uses 6 bit color values. Red and blue ignore the LSB.
drawLine(x1, y1, x2, y2, 8bitcolor);//draw a line from (x1,y1) to (x2,y2) with an 8 bit color
drawLine(x1, y1, x2, y2, 16bitcolor);//draw a line from (x1,y1) to (x2,y2) with an 16 bit color
drawLine(x1, y1, x2, y2, red, green, blue);//like above, but uses 6 bit color values. Red and blue ignore the LSB.
*/

void TinyScreen::clearWindow(uint8_t x, uint8_t y, uint8_t w, uint8_t h) {
  if(x>xMax||y>yMax)return;
  uint8_t x2=x+w-1;
  uint8_t y2=y+h-1;
  if(x2>xMax)x2=xMax;
  if(y2>yMax)y2=yMax;
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  CS_L;
  setWindow(x, y, x+w-1, y+h-1);
  CS_H;
  CS_L;
  (_bitDepth) ? pushBlock16(0x0000, w*h) : pushBlock8(0x0000, w*h);
  CS_H;
#else
  startCommand();
  TSSPI->transfer(0x25);//clear window
  TSSPI->transfer(x);TSSPI->transfer(y);
  TSSPI->transfer(x2);TSSPI->transfer(y2);
  endTransfer();
#endif
#if TS_USE_DELAY
  delayMicroseconds(400);
#endif
}

void TinyScreen::clearScreen(){
  #if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  if(_type == RP2040TVMini) clearWindow(0,0,96,64);
  else if(_type == RP2040TV) clearWindow(0,0,240,135);
  #else
  clearWindow(0,0,96,64);
  #endif // defined
}

void TinyScreen::drawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t f, uint8_t r, uint8_t g, uint8_t b)
{
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  if(_bitDepth) drawRect(x, y, w, h, f, ((b & 0b11111000) << 8) | ((g & 0b11111100) << 3) | (r >> 3));
  else drawRect(x, y, w, h, f, ((r & 0b11000000) >> 6) | ((g & 0b11100000) >> 3) | (b & 0b11100000));
#else
  if(x>xMax||y>yMax)return;
  uint8_t x2=x+w-1;
  uint8_t y2=y+h-1;
  if(x2>xMax)x2=xMax;
  if(y2>yMax)y2=yMax;
  uint8_t fill=0;
  if(f)fill=1;
  startCommand();
  TSSPI->transfer(0x26);//set fill
  TSSPI->transfer(fill);

  TSSPI->transfer(0x22);//draw rectangle
  TSSPI->transfer(x);TSSPI->transfer(y);
  TSSPI->transfer(x2);TSSPI->transfer(y2);
  //outline
  TSSPI->transfer(b);TSSPI->transfer(g);TSSPI->transfer(r);
  //fill
  TSSPI->transfer(b);TSSPI->transfer(g);TSSPI->transfer(r);
  endTransfer();
#endif
#if TS_USE_DELAY
  delayMicroseconds(400);
#endif
}

void TinyScreen::drawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t f, uint16_t color)
{
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  if(x>xMax||y>yMax)return;
  uint8_t x2=x+w-1;
  uint8_t y2=y+h-1;
  if(x2>xMax)x2=xMax;
  if(y2>yMax)y2=yMax;
  if(f)
  {
    startCommand();
    setWindow(x, y, x+w-1, y+h-1);
    endTransfer();
    startData();
    (_bitDepth) ? pushBlock16(color, w*h) : pushBlock8(color, w*h);
    endTransfer();
  }
  else
  {
    startCommand();
    setWindow(x, y, x+w-1, y);
    endTransfer();
    startData();
    //pushBlock(color, w);
    (_bitDepth) ? pushBlock16(color, w) : pushBlock8(color, w);
    endTransfer();

    startCommand();
    setWindow(x+w-1, y+1, x+w-1, y+h-1);
    endTransfer();
    startData();
    //pushBlock(color, h-1);
    (_bitDepth) ? pushBlock16(color, h-1) : pushBlock8(color, h-1);
    endTransfer();

    startCommand();
    setWindow(x, y+1, x, y+h-1);
    endTransfer();
    startData();
    //pushBlock(color, h-1);
    (_bitDepth) ? pushBlock16(color, h-1) : pushBlock8(color, h-1);
    endTransfer();

    startCommand();
    setWindow(x+1, y+h-1, x+w-2, y+h-1);
    endTransfer();
    startData();
    //pushBlock(color, w-2);
    (_bitDepth) ? pushBlock16(color, w-2) : pushBlock8(color, w-2);
    endTransfer();
  }
#else
  uint16_t r,g,b;
  if(_bitDepth){
    r=(color)&0x1F;//five bits
    g=(color>>5)&0x3F;//six bits
    b=(color>>11)&0x1F;//five bits
    r=r<<1;//shift to fill six bits
    g=g<<0;//shift to fill six bits
    b=b<<1;//shift to fill six bits
  }else{
    r=(color)&0x03;//two bits
    g=(color>>2)&0x07;//three bits
    b=(color>>5)&0x07;//three bits
    r|=(r<<4)|(r<<2);//copy to fill six bits
    g|=g<<3;//copy to fill six bits
    b|=b<<3;//copy to fill six bits
  }
  drawRect(x,y,w,h,f,r,g,b);
#endif
}

void TinyScreen::drawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1, uint8_t r, uint8_t g, uint8_t b) {
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  if(_bitDepth) drawLine(x0, y0, x1, y1, ((b & 0b11111000) << 8) | ((g & 0b11111100) << 3) | (r >> 3));
  else drawLine(x0, y0, x1, y1, ((r & 0b11000000) >> 6) | ((g & 0b11100000) >> 3) | (b & 0b11100000));
#else
  if(x0>xMax)x0=xMax;
  if(y0>yMax)y0=yMax;
  if(x1>xMax)x1=xMax;
  if(y1>yMax)y1=yMax;
  startCommand();
  TSSPI->transfer(0x21);//draw line
  TSSPI->transfer(x0);TSSPI->transfer(y0);
  TSSPI->transfer(x1);TSSPI->transfer(y1);
  TSSPI->transfer(b);TSSPI->transfer(g);TSSPI->transfer(r);
  endTransfer();
#if TS_USE_DELAY
  delayMicroseconds(100);
#endif
#endif
}

void TinyScreen::drawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1, uint16_t color) {
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  if(x0>xMax)x0=xMax;
  if(y0>yMax)y0=yMax;
  if(x1>xMax)x1=xMax;
  if(y1>yMax)y1=yMax;
  int16_t steep = abs(y1 - y0) > abs(x1 - x0);
  if (steep) {
    swap(x0, y0);
    swap(x1, y1);
  }

  if (x0 > x1) {
    swap(x0, x1);
    swap(y0, y1);
  }

  int16_t dx, dy;
  dx = x1 - x0;
  dy = abs(y1 - y0);

  int16_t err = dx >> 1;
  int16_t ystep;

  if (y0 < y1) {
    ystep = 1;
  } else {
    ystep = -1;
  }

  // Place at correct start pixel
  startCommand();
  if(steep)
  {
    setX(y0, y0); // Sub-segment is horizontal
    setY(x0, yMax); // Sub-segment is horizontal
  }
  else
  {
    setY(y0, y0); // Sub-segment is vertical
    setX(x0, xMax);
  }
  endTransfer();

  // Start by writing colors
  startData();
  int cnt = 0;
  if(_bitDepth)
  {
    for (; x0 <= x1; x0++) {
      cnt++;
      err -= dy;
      if (err < 0) {
        // Step change, re-align window
        pushBlock16(color, cnt);
        cnt = 0;
        endTransfer();
        y0 += ystep;
        if(steep)
        {
          setX(y0, y0); // Sub-segment is horizontal
          setY(x0+1, yMax); // Sub-segment is horizontal
        }
        else
        {
          setY(y0, y0); // Sub-segment is vertical
          setX(x0+1, xMax);
        }
        err += dx;
        // Start blasting colors again
        startData();
      }
    }
    pushBlock16(color, cnt);
  }
  else
  {
    for (; x0 <= x1; x0++) {
      cnt++;
      err -= dy;
      if (err < 0) {
        // Step change, re-align window
        pushBlock8(color, cnt);
        cnt = 0;
        endTransfer();
        y0 += ystep;
        if(steep)
        {
          setX(y0, y0); // Sub-segment is horizontal
          setY(x0+1, yMax); // Sub-segment is horizontal
        }
        else
        {
          setY(y0, y0); // Sub-segment is vertical
          setX(x0+1, xMax);
        }
        err += dx;
        // Start blasting colors again
        startData();
      }
    }
    pushBlock8(color, cnt);
  }
  //write16(color);
  endTransfer();
#else
  uint16_t r,g,b;
  if(_bitDepth){
    r=(color)&0x1F;//five bits
    g=(color>>5)&0x3F;//six bits
    b=(color>>11)&0x1F;//five bits
    r=r<<1;//shift to fill six bits
    g=g<<0;//shift to fill six bits
    b=b<<1;//shift to fill six bits
  }else{
    r=(color)&0x03;//two bits
    g=(color>>2)&0x07;//three bits
    b=(color>>5)&0x07;//three bits
    r|=(r<<4)|(r<<2);//copy to fill six bits
    g|=g<<3;//copy to fill six bits
    b|=b<<3;//copy to fill six bits
  }
  drawLine(x0,y0,x1,y1,r,g,b);
#endif
}

#undef swap

/*
Pixel manipulation
drawPixel(x,y,color);//set pixel (x,y) to specified color. This is slow because we need to send commands setting the x and y, then send the pixel data.
writePixel(color);//write the current pixel to specified color. Less slow than drawPixel, but still has to ready display for pixel data
writeBuffer(buffer,count);//optimized write of a large buffer of 8 bit data. Must be wrapped with startData() and endTransfer(), but there can be any amount of calls to writeBuffer between.
*/

void TinyScreen::drawPixel(uint8_t x, uint8_t y, uint16_t color)
{
  if(x>xMax||y>yMax)return;
  goTo(x,y);
  writePixel(color);
}

void TinyScreen::writePixel(uint16_t color) {
  startData();
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  write16(color);
#else
  if(_bitDepth)
    TSSPI->transfer(color>>8);
  TSSPI->transfer(color);
#endif // defined
  endTransfer();
}

void TinyScreen::writeBuffer(uint8_t *buffer,int count) {
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
//write8(buffer[0])
  write8(buffer[0]);
  for(int j=1;j<count;j++){
    write8(buffer[j]);
}
#else
  uint8_t temp;
  TS_SPI_SET_DATA_REG(buffer[0]);
  for(int j=1;j<count;j++){
    temp=buffer[j];
    TS_SPI_SEND_WAIT();
    TS_SPI_SET_DATA_REG(temp);
  }
  TS_SPI_SEND_WAIT();
#endif // defined
}

/*
TinyScreen commands
setBrightness(brightness);//sets main current level, valid levels are 0-15
on();//turns display on
off();//turns display off, uses less power
setBitDepth(depth);//boolean- 0 is 8 bit, 1 is 16 bit
setFlip(flip);//done in hardware on the SSD1331. boolean- 0 is normal, 1 is upside down
setMirror(mirror);//done in hardware on the SSD1331. boolean- 0 is normal, 1 is mirrored across Y axis
*/

void TinyScreen::setBrightness(uint8_t brightness) {
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)

#else
  if(brightness>15)brightness=15;
  startCommand();
  TSSPI->transfer(0x87);//set master current
  TSSPI->transfer(brightness);
  endTransfer();
#endif // defined
}

void TinyScreen::on(void) {
  startCommand();
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  if(_type == RP2040TVMini) writeCommand(0xAF); // DISPLAYON
  else if(_type == RP2040TV) writeCommand(0x29);
#else
  if(!_externalIO){
    digitalWrite(TSP_PIN_SHDN,HIGH);
  }
  delayMicroseconds(10000);
  TSSPI->transfer(0xAF); // DISPLAYON
#endif
  endTransfer();
}

void TinyScreen::off(void) {
  startCommand();
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  if(_type == RP2040TVMini) writeCommand(0xAE); // DISPLAYON
  else if(_type == RP2040TV) writeCommand(0x28);
#else
  TSSPI->transfer(0xAE); // DISPLAYON
  if(_externalIO){
    writeGPIO(GPIO_RegData,~GPIO_SHDN);//bost converter off
    //any other write will turn the boost converter back on
  }else{
    digitalWrite(TSP_PIN_SHDN,LOW);//SHDN
  }
#endif
  endTransfer();
}

void TinyScreen::setBitDepth(uint8_t b){
  _bitDepth=b;
  writeRemap();
}

void TinyScreen::setFlip(uint8_t f){
  _flipDisplay=f;
  writeRemap();
}

void TinyScreen::setMirror(uint8_t m){
  _mirrorDisplay=m;
  writeRemap();
}

void TinyScreen::setColorMode(uint8_t cm){
  _colorMode=cm;
  writeRemap();
}

/*
The SSD1331 remap command sets a lot of driver variables, these are kept in memory
and are all written when a change is made.
*/

void TinyScreen::writeRemap(void){
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  uint8_t remap = 0x24 | 0x11;
  if(_type == RP2040TV) remap = 0x60;
#else
  uint8_t remap=(1<<5)|(1<<2);
#endif
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
    if(_flipDisplay)
      if(_type == RP2040TVMini) remap^=((1<<4)|(1<<1));
      else remap ^= 0x80 ^ 0x40;
    if(_mirrorDisplay)
      if(_type == RP2040TVMini) remap^=(1<<1);
      else remap ^= 0x80;
    if(_bitDepth)
      if(_type == RP2040TVMini) remap|=(1<<6);
      else remap ^= 0; // ST7789 uses a custom command for setting bit depth.
    if(_colorMode)
      if(_type == RP2040TVMini) remap^=(1<<2);
      else remap ^= (1 << 3);
#else
  if(_flipDisplay)
    remap|=((1<<4)|(1<<1));
  if(_mirrorDisplay)
    remap^=(1<<1);
  if(_bitDepth)
    remap|=(1<<6);
  if(_colorMode)
    remap^=(1<<2);
#endif
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  if(_type == RP2040TVMini) writeCommand(0xA0);
  else if(_type == RP2040TV) writeCommand(ST7789_MADCTL);
  writeData(remap);
#else
  startCommand();
  TSSPI->transfer(0xA0); // SETREMAP
  TSSPI->transfer(remap);
  endTransfer();
#endif
}

void TinyScreen::begin(void) {
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  pinMode(9, OUTPUT);
  if(_type == RP2040TVMini) digitalWrite(9, LOW);
  else if(_type == RP2040TV) digitalWrite(9, HIGH);

  //tft.init(0);
  // Initialization
  pinMode(RPTVM_PIN_CS, OUTPUT);
  digitalWrite(RPTVM_PIN_CS, HIGH); // Chip select high (inactive)
  pinMode(RPTVM_PIN_DC, OUTPUT);
  digitalWrite(RPTVM_PIN_DC, HIGH); // Data/Command high = data mode
  pinMode(RPTVM_PIN_RST, OUTPUT);
  digitalWrite(RPTVM_PIN_RST, HIGH); // Set high, do not share pin with another SPI device
  pioinit(80000000);
  CS_H;

  // Initialization
  digitalWrite(RPTVM_PIN_RST, HIGH);
  delay(5);
  digitalWrite(RPTVM_PIN_RST, LOW);
  delay(20);
  digitalWrite(RPTVM_PIN_RST, HIGH);
  delay(150);
  CS_L;
  if(_type == RP2040TVMini)
  {
    colSetCommand = TFT_CASET;
    rowSetCommand = TFT_PASET;
    writeRamCommand = TFT_RAMWR;
    cgramOff = 32;
    setWindow = setWindowSSD1357;
    setXFunc = setXSSD1357;
    setYFunc = setYSSD1357;
    xOff = 0;
    yOff = 32;
    // RP2040TVMini init
    writeCommand(0xFD); // COMMANDLOCK
    writeData(0x12);
    //writeCommand(0xFD); // COMMANDLOCK
    //writeData(0xB1);
    writeCommand(0xAE); // DISPLAYOFF
    writeCommand(0xB0); // CLOCKDIV
    writeData(0xB0);
    writeCommand(0xCA); // MUXRATIO
    writeData(127);
    writeCommand(0xA2); // DISPLAYOFFSET
    writeData(0x40);
    //writeCommand(0xB5); // SETGPIO
    //writeData(0x00);
    //writeCommand(0xAB); // FUNCTIONSELECT
    //writeData(0x01);
    writeCommand(0xB1); // PRECHARGE (phase length?)
    writeData(0x32);
    writeCommand(0xBE); // VCOMH
    writeData(0x05);
    writeCommand(0xB6); // precharge period
    writeData(0x01);
    writeCommand(0xBB); // actual precharge?
    writeData(0x17);
    writeCommand(0xA6); // NORMALDISPLAY
    writeCommand(0xC1); // CONTRASTABC
    writeData(0x88);
    writeData(0x32);
    writeData(0x88);
    writeCommand(0xC7); // CONTRASTMASTER
    writeData(0x0F);
    //writeCommand(0xB4); // SETVSL
    //writeData(0xA0);
    //writeData(0xB5);
    //writeData(0x55);
    writeCommand(0xB6); // PRECHARGE2
    writeData(0x01);


    int j;
  uint8_t gamma[63]=
  {
  	0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,
  	0x0C,0x0D,0x0E,0x0F,0x10,0x11,0x12,0x13,0x15,0x17,
  	0x19,0x1B,0x1D,0x1F,0x21,0x23,0x25,0x27,0x2A,0x2D,
  	0x30,0x33,0x36,0x39,0x3C,0x3F,0x42,0x45,0x48,0x4C,
  	0x50,0x54,0x58,0x5C,0x60,0x64,0x68,0x6C,0x70,0x74,
  	0x78,0x7D,0x82,0x87,0x8C,0x91,0x96,0x9B,0xA0,0xA5,
  	0xAA,0xAF,0xB4,
  };
  	writeCommand(0xB8);			// Set Gray Scale Table

  	for(j=0;j<63;j++)
  	{
     		writeData(gamma[j]);
  	}
    writeCommand(0xAF); // DISPLAYON

    #ifdef TFT_INVERSION_ON
    writeCommand(TFT_INVON);
    #endif

    #ifdef TFT_INVERSION_OFF
    writeCommand(TFT_INVOFF);
    #endif

    CS_H;

    // Set rotation
    CS_L;

    uint8_t madctl = 0x64;

    switch (1) {
      case 0:
        madctl |= 0x12;
        break;
      case 1:
        madctl |= 0x11;
        break;
      case 2:
        madctl |= 0x00;
        break;
      case 3:
        madctl |= 0x03;
        break;
    }

    writeRemap();
    writeData(0x00);
    delay(10);
    CS_H;
    CS_L;
    setWindow(0, 0, 63, 63);
    CS_H;
    clearWindow(0,0,64,64);
    digitalWrite(9, HIGH);
  }
  else if(_type == RP2040TV)
  {
    colSetCommand = ST7789_CASET;
    rowSetCommand = ST7789_RASET;
    writeRamCommand = ST7789_RAMWR;
    cgramOff = 0;
    setWindow = setWindowST7789;
    setXFunc = setXST7789;
    setYFunc = setYST7789;
    xOff = 40;
    yOff = 53;
    // Regular TinyTV2 init
    writeCommand(ST7789_SLPOUT);   // Sleep out
  delay(120);

  writeCommand(ST7789_NORON);    // Normal display mode on

  //------------------------------display and color format setting--------------------------------//
  writeCommand(ST7789_MADCTL);
  //writeData(0x00);
  writeData(TFT_MAD_BGR);

  // JLX240 display datasheet
  writeCommand(0xB6);
  writeData(0x0A);
  writeData(0x82);

  writeCommand(ST7789_RAMCTRL);
  writeData(0x00);
  writeData(0xE0); // 5 to 6 bit conversion: r0 = r5, b0 = b5

  writeCommand(ST7789_COLMOD);
  writeData(0x55);
  delay(10);

  //--------------------------------ST7789V Frame rate setting----------------------------------//
  writeCommand(ST7789_PORCTRL);
  writeData(0x0c);
  writeData(0x0c);
  writeData(0x00);
  writeData(0x33);
  writeData(0x33);

  writeCommand(ST7789_GCTRL);      // Voltages: VGH / VGL
  writeData(0x35);

  //---------------------------------ST7789V Power setting--------------------------------------//
  writeCommand(ST7789_VCOMS);
  writeData(0x28);		// JLX240 display datasheet

  writeCommand(ST7789_LCMCTRL);
  writeData(0x0C);

  writeCommand(ST7789_VDVVRHEN);
  writeData(0x01);
  writeData(0xFF);

  writeCommand(ST7789_VRHS);       // voltage VRHS
  writeData(0x10);

  writeCommand(ST7789_VDVSET);
  writeData(0x20);

  writeCommand(ST7789_FRCTR2);
  writeData(0x0f);

  writeCommand(ST7789_PWCTRL1);
  writeData(0xa4);
  writeData(0xa1);

  //--------------------------------ST7789V gamma setting---------------------------------------//
  writeCommand(ST7789_PVGAMCTRL);
  writeData(0xd0);
  writeData(0x00);
  writeData(0x02);
  writeData(0x07);
  writeData(0x0a);
  writeData(0x28);
  writeData(0x32);
  writeData(0x44);
  writeData(0x42);
  writeData(0x06);
  writeData(0x0e);
  writeData(0x12);
  writeData(0x14);
  writeData(0x17);

  writeCommand(ST7789_NVGAMCTRL);
  writeData(0xd0);
  writeData(0x00);
  writeData(0x02);
  writeData(0x07);
  writeData(0x0a);
  writeData(0x28);
  writeData(0x31);
  writeData(0x54);
  writeData(0x47);
  writeData(0x0e);
  writeData(0x1c);
  writeData(0x17);
  writeData(0x1b);
  writeData(0x1e);

  writeCommand(ST7789_INVON);

  writeCommand(ST7789_CASET);    // Column address set
  writeData(0x00);
  writeData(0x00);
  writeData(0x00);
  writeData(0xE5);    // 239

  writeCommand(ST7789_RASET);    // Row address set
  writeData(0x00);
  writeData(0x00);
  writeData(0x01);
  writeData(0x3F);    // 319

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  CS_H;
  delay(120);
  CS_L;

  writeCommand(ST7789_DISPON);    //Display on
  delay(120);

  #ifdef TFT_INVERSION_ON
  writeCommand(TFT_INVON);
  #endif

  #ifdef TFT_INVERSION_OFF
  writeCommand(TFT_INVOFF);
  #endif

  CS_H;
  CS_L;

  writeCommand(ST7789_MADCTL);
  switch (1) {
    case 0: // Portrait
      writeData(TFT_MAD_BGR);
      break;

    case 1: // Landscape (Portrait + 90)
      writeData(TFT_MAD_MX | TFT_MAD_MV | TFT_MAD_BGR);
      break;

      case 2: // Inverter portrait
      writeData(TFT_MAD_MX | TFT_MAD_MY | TFT_MAD_RGB);
       break;
    case 3: // Inverted landscape
      writeData(TFT_MAD_MV | TFT_MAD_MY | TFT_MAD_BGR);
      break;
  }
  CS_H;
  // Set window
  CS_L;
  setWindow(0, 0, 239, 134);
  CS_H;
  CS_L;
  pushBlock16(0x0000, 264*135);
  CS_H;
  digitalWrite(9, LOW);
  }
  else
  {
    // No valid initialization
  }
#else
//init SPI
TSSPI->begin();
TSSPI->setDataMode(SPI_MODE0);//wrong mode, works because we're only writing. this mode is compatible with SD cards.
#if defined(ARDUINO_ARCH_AVR)
  TSSPI->setClockDivider(SPI_CLOCK_DIV2);
#elif defined(ARDUINO_ARCH_SAMD)
  TSSPI->setClockDivider(4);
#endif

  if(_externalIO){
    //standard TinyScreen- setup GPIO, reset SSD1331
    writeGPIO(GPIO_RegData,~GPIO_RES);//reset low, other pins high
    writeGPIO(GPIO_RegDir,~GPIO_RES);//set reset to output
    delay(5);
    writeGPIO(GPIO_RegDir,~(GPIO_CS|GPIO_DC|GPIO_SHDN));//reset to input, CS/DC/SHDN output
    writeGPIO(GPIO_RegPullUp,GPIO_BTN1|GPIO_BTN2|GPIO_BTN3|GPIO_BTN4);//button pullup enable
  }else{
    //otherwise TinyScreen+, connected directly to IO pins
    pinMode(TSP_PIN_SHDN,OUTPUT);pinMode(TSP_PIN_DC,OUTPUT);pinMode(TSP_PIN_CS,OUTPUT);pinMode(TSP_PIN_RST,OUTPUT);
    digitalWrite(TSP_PIN_SHDN,LOW);digitalWrite(TSP_PIN_DC,HIGH);digitalWrite(TSP_PIN_CS,HIGH);digitalWrite(TSP_PIN_RST,HIGH);
    pinMode(TSP_PIN_BT1,INPUT_PULLUP);pinMode(TSP_PIN_BT2,INPUT_PULLUP);pinMode(TSP_PIN_BT3,INPUT_PULLUP);pinMode(TSP_PIN_BT4,INPUT_PULLUP);
    //reset
    digitalWrite(TSP_PIN_RST,LOW);
    delay(5);
    digitalWrite(TSP_PIN_RST,HIGH);
  }
  delay(10);

  //datasheet SSD1331 init sequence
  const uint8_t init[32]={0xAE, 0xA1, 0x00, 0xA2, 0x00, 0xA4, 0xA8, 0x3F,
  0xAD, 0x8E, 0xB0, 0x0B, 0xB1, 0x31, 0xB3, 0xF0, 0x8A, 0x64, 0x8B,
  0x78, 0x8C, 0x64, 0xBB, 0x3A, 0xBE, 0x3E, 0x81, 0x91, 0x82, 0x50, 0x83, 0x7D};
  off();
  startCommand();
  for(uint8_t i=0;i<32;i++)
    TSSPI->transfer(init[i]);
  endTransfer();
  //use libarary functions for remaining init
  setBrightness(5);
  writeRemap();
  clearWindow(0,0,96,64);
  on();
#endif // defined
}

/*
TinyScreen constructor
type tells us if we're using a regular TinyScreen, alternate addresss TinyScreen, or a TinyScreen+
address sets I2C address of SX1505 to 0x20 or 0x21, which is set by the position of a resistor near SX1505 (see schematic and board design)
*/

TinyScreen::TinyScreen(uint8_t type){
  _externalIO=0;
  _cursorX=0;
  _cursorY=0;
  _fontHeight=0;
  _fontFirstCh=0;
  _fontLastCh=0;
  _fontDescriptor=0;
  _fontBitmap=0;
  _fontColor=0xFFFF;
  _fontBGcolor=0x0000;
  _bitDepth=0;
  _flipDisplay=0;
  _mirrorDisplay=0;
  _colorMode=0;
  _type=type;

  //type determines the SPI interface IO configuration
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  if(_type==RP2040TV){
    xMax = 239;
    yMax = 134;
  }else if(_type==RP2040TVMini){
    xMax = 63;
    yMax = 63;
  }
#else
  if(_type==TinyScreenDefault){
    TSSPI=&SPI;
    _externalIO=1;
    _addr=0;
    xMax = 95;
    yMax = 63;
  }else if(_type==TinyScreenAlternate){
    TSSPI=&SPI;
    _externalIO=1;
    _addr=1;
    xMax = 95;
    yMax = 63;
  }else if(_type==TinyScreenPlus){
#if defined(ARDUINO_ARCH_SAMD)
    TSSPI=&SPI1;
#endif
    _externalIO=0;
    xMax = 95;
    yMax = 63;
  }else{
    TSSPI=&SPI;
    _externalIO=1;
    _addr=0;
    xMax = -1;
    yMax = -1;
  }
#endif
}

/*
TinyScreen Text Display
setCursor(x,y);//set text cursor position to (x,y)
setFont(descriptor);//set font data to use
fontColor(text color, background color);//sets text and background color
getFontHeight();//returns height of font

getStringWidth
*/

void TinyScreen::setCursor(uint8_t x, uint8_t y){
  _cursorX=x;
  _cursorY=y;
}

void TinyScreen::setFont(const FONT_INFO& fontInfo){
  _fontHeight=fontInfo.height;
  _fontFirstCh=fontInfo.startCh;
  _fontLastCh=fontInfo.endCh;
  _fontDescriptor=fontInfo.charDesc;
  _fontBitmap=fontInfo.bitmap;
}

void TinyScreen::fontColor(uint16_t f, uint16_t g){
  _fontColor=f;
  _fontBGcolor=g;
}

uint8_t TinyScreen::getFontHeight(const FONT_INFO& fontInfo){
  return fontInfo.height;
}

uint8_t TinyScreen::getFontHeight(){
  return _fontHeight;
}

uint8_t TinyScreen::getPrintWidth(char * st){
  if(!_fontFirstCh)return 0;
  uint8_t i,amtCh,totalWidth;
  totalWidth=0;
  amtCh=strlen(st);
  for(i=0;i<amtCh;i++){
    totalWidth+=pgm_read_byte(&_fontDescriptor[st[i]-_fontFirstCh].width)+1;
  }
  return totalWidth;
}

size_t TinyScreen::write(uint8_t ch){

#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  if(!_fontFirstCh)return 1;
  if(ch<_fontFirstCh || ch>_fontLastCh)return 1;
  if(_cursorX>xMax || _cursorY>yMax)return 1;
  uint8_t chWidth=pgm_read_byte(&_fontDescriptor[ch-_fontFirstCh].width);
  uint8_t bytesPerRow=chWidth/8;
  if(chWidth>bytesPerRow*8)
    bytesPerRow++;
  uint16_t offset=pgm_read_word(&_fontDescriptor[ch-_fontFirstCh].offset)+(bytesPerRow*_fontHeight)-1;

  setX(_cursorX,_cursorX+chWidth+1);
  setY(_cursorY,_cursorY+_fontHeight);

  startData();
  for(uint8_t y=0; y<_fontHeight && y+_cursorY<yMax+1; y++){
    if(_bitDepth){
      write8(_fontBGcolor>>8);
    }
    write8(_fontBGcolor);
    for(uint8_t byte=0; byte<bytesPerRow; byte++){
      uint8_t data=pgm_read_byte(_fontBitmap+offset-y-((bytesPerRow-byte-1)*_fontHeight));
      uint8_t bits=byte*8;
        for(uint8_t i=0; i<8 && (bits+i)<chWidth && (bits+i+_cursorX)<xMax; i++){
          if(data&(0x80>>i)){
            if(_bitDepth){
              write8(_fontColor>>8);
            }
            write8(_fontColor);
           }else{
            if(_bitDepth){
              write8(_fontBGcolor>>8);
            }
            write8(_fontBGcolor);
          }
      }
    }
    if((_cursorX+chWidth)<xMax){
      if(_bitDepth){
        write8(_fontBGcolor>>8);
      }
      write8(_fontBGcolor);
    }
  }
  endTransfer();
  _cursorX+=(chWidth+1);
  return 1;
#else
  if(!_fontFirstCh)return 1;
  if(ch<_fontFirstCh || ch>_fontLastCh)return 1;
  if(_cursorX>xMax || _cursorY>yMax)return 1;
  uint8_t chWidth=pgm_read_byte(&_fontDescriptor[ch-_fontFirstCh].width);
  uint8_t bytesPerRow=chWidth/8;
  if(chWidth>bytesPerRow*8)
    bytesPerRow++;
  uint16_t offset=pgm_read_word(&_fontDescriptor[ch-_fontFirstCh].offset)+(bytesPerRow*_fontHeight)-1;

  setX(_cursorX,_cursorX+chWidth+1);
  setY(_cursorY,_cursorY+_fontHeight);

  startData();
  for(uint8_t y=0; y<_fontHeight && y+_cursorY<yMax+1; y++){
    if(_bitDepth){

      TS_SPI_SET_DATA_REG(_fontBGcolor>>8);
      TS_SPI_SEND_WAIT();
    }
    TS_SPI_SET_DATA_REG(_fontBGcolor);
    for(uint8_t byte=0; byte<bytesPerRow; byte++){
      uint8_t data=pgm_read_byte(_fontBitmap+offset-y-((bytesPerRow-byte-1)*_fontHeight));
      uint8_t bits=byte*8;
        for(uint8_t i=0; i<8 && (bits+i)<chWidth && (bits+i+_cursorX)<xMax; i++){
          TS_SPI_SEND_WAIT();
          if(data&(0x80>>i)){
            if(_bitDepth){
              TS_SPI_SET_DATA_REG(_fontColor>>8);
              TS_SPI_SEND_WAIT();
            }
            TS_SPI_SET_DATA_REG(_fontColor);
           }else{
            if(_bitDepth){
              TS_SPI_SET_DATA_REG(_fontBGcolor>>8);
              TS_SPI_SEND_WAIT();
            }
            TS_SPI_SET_DATA_REG(_fontBGcolor);
          }
      }
    }
    TS_SPI_SEND_WAIT();
    if((_cursorX+chWidth)<xMax){
      if(_bitDepth){
        TS_SPI_SET_DATA_REG(_fontBGcolor>>8);
        TS_SPI_SEND_WAIT();
      }
      TS_SPI_SET_DATA_REG(_fontBGcolor);
      TS_SPI_SEND_WAIT();
    }
  }
  endTransfer();
  _cursorX+=(chWidth+1);
  return 1;
#endif
}

/*
TinyScreen+ SAMD21 DMA write
Example code taken from https://github.com/manitou48/ZERO/blob/master/SPIdma.ino
Thanks manitou!
This code is experimental
*/


#if defined(ARDUINO_ARCH_SAMD)

typedef struct {
  uint16_t btctrl;
  uint16_t btcnt;
  uint32_t srcaddr;
  uint32_t dstaddr;
  uint32_t descaddr;
} dmacdescriptor ;
volatile dmacdescriptor wrb[12] __attribute__ ((aligned (16)));
dmacdescriptor descriptor_section[12] __attribute__ ((aligned (16)));
dmacdescriptor descriptor __attribute__ ((aligned (16)));

const uint32_t DMAchannel = 0;
volatile uint32_t dmaReady=true;


void DMAC_Handler() {
  // interrupts DMAC_CHINTENCLR_TERR DMAC_CHINTENCLR_TCMPL DMAC_CHINTENCLR_SUSP
  uint8_t active_channel;

  // disable irqs ?
  __disable_irq();
  active_channel =  DMAC->INTPEND.reg & DMAC_INTPEND_ID_Msk; // get channel number
  DMAC->CHID.reg = DMAC_CHID_ID(active_channel);
  if(DMAC->CHINTFLAG.reg) dmaReady=true;
  DMAC->CHINTFLAG.reg = DMAC_CHINTENCLR_TCMPL; // clear
  DMAC->CHINTFLAG.reg = DMAC_CHINTENCLR_TERR;
  DMAC->CHINTFLAG.reg = DMAC_CHINTENCLR_SUSP;
  __enable_irq();
}

#endif

uint8_t TinyScreen::getReadyStatusDMA(){
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  return !(dma_channel_is_busy(dma_tx_channel));
#elif defined(ARDUINO_ARCH_SAMD)
  return dmaReady;
#else
  //it's tough to raise an error about not having DMA in the IDE- try to fall back to regular software transfer
  return 1;//always return ready
#endif
}

void TinyScreen::writeBufferDMA(uint8_t *txdata,int n) {
  if (n == 0) return;
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  //write16(0xFFFF);
  while (dma_channel_is_busy(dma_tx_channel));

  channel_config_set_bswap(&dma_tx_config, true);
  channel_config_set_transfer_data_size(&dma_tx_config, DMA_SIZE_16);
  //fifoWait(4);
  write8(*txdata);
  txdata++;
  tft_pio->sm[pio_sm].instr = pio_instr_jmp8;
  //TX_FIFO = 0;
  dma_channel_configure(dma_tx_channel, &dma_tx_config, &tft_pio->txf[pio_sm], (uint16_t*)txdata, (n>>1), true);
  stallWait();
#elif defined(ARDUINO_ARCH_SAMD)
while(!dmaReady);
uint32_t temp_CHCTRLB_reg;
// set up transmit channel
DMAC->CHID.reg = DMAC_CHID_ID(DMAchannel);
DMAC->CHCTRLA.reg &= ~DMAC_CHCTRLA_ENABLE;
DMAC->CHCTRLA.reg = DMAC_CHCTRLA_SWRST;
DMAC->SWTRIGCTRL.reg &= (uint32_t)(~(1 << DMAchannel));
if(_externalIO){
  temp_CHCTRLB_reg = DMAC_CHCTRLB_LVL(0) | DMAC_CHCTRLB_TRIGSRC(SERCOM1_DMAC_ID_TX) | DMAC_CHCTRLB_TRIGACT_BEAT;
}else{
  temp_CHCTRLB_reg = DMAC_CHCTRLB_LVL(0) | DMAC_CHCTRLB_TRIGSRC(SERCOM4_DMAC_ID_TX) | DMAC_CHCTRLB_TRIGACT_BEAT;
}
DMAC->CHCTRLB.reg = temp_CHCTRLB_reg;
DMAC->CHINTENSET.reg = DMAC_CHINTENSET_MASK ; // enable interrupts
descriptor.descaddr = 0;
if(_externalIO){
  descriptor.dstaddr = (uint32_t) &SERCOM1->SPI.DATA.reg;
}else{
  descriptor.dstaddr = (uint32_t) &SERCOM4->SPI.DATA.reg;
}
descriptor.btcnt =  n;
descriptor.srcaddr = (uint32_t)txdata;
descriptor.btctrl =  DMAC_BTCTRL_VALID;
descriptor.srcaddr += n;
descriptor.btctrl |= DMAC_BTCTRL_SRCINC;
memcpy(&descriptor_section[DMAchannel],&descriptor, sizeof(dmacdescriptor));

dmaReady = false;

// start channel
DMAC->CHID.reg = DMAC_CHID_ID(DMAchannel);
DMAC->CHCTRLA.reg |= DMAC_CHCTRLA_ENABLE;

//DMAC->CHID.reg = DMAC_CHID_ID(chnltx);   //disable DMA to allow lib SPI- necessary? needs to be done after completion
//DMAC->CHCTRLA.reg &= ~DMAC_CHCTRLA_ENABLE;
#else
//it's tough to raise an error about not having DMA in the IDE- try to fall back to regular software transfer
writeBuffer(txdata,n);//just write the data without DMA
#endif
}

void TinyScreen::initDMA(void){
#if defined(ARDUINO_ARCH_MBED_RP2040) | defined(ARDUINO_ARCH_RP2040)
  dma_tx_channel = dma_claim_unused_channel(false);

  if (dma_tx_channel < 0) return;

  dma_tx_config = dma_channel_get_default_config(dma_tx_channel);

  //channel_config_set_transfer_data_size(&dma_tx_config, DMA_SIZE_16);
  channel_config_set_dreq(&dma_tx_config, pio_get_dreq(tft_pio, pio_sm, true));
#elif defined(ARDUINO_ARCH_SAMD)
  //probably on by default
  PM->AHBMASK.reg |= PM_AHBMASK_DMAC ;
  PM->APBBMASK.reg |= PM_APBBMASK_DMAC ;
  NVIC_EnableIRQ( DMAC_IRQn ) ;

  DMAC->BASEADDR.reg = (uint32_t)descriptor_section;
  DMAC->WRBADDR.reg = (uint32_t)wrb;
  DMAC->CTRL.reg = DMAC_CTRL_DMAENABLE | DMAC_CTRL_LVLEN(0xf);
#else
  //it's tough to raise an error about not having DMA in the IDE- try to fall back to regular software transfer
  //ignore init
#endif
}
